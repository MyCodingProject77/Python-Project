"""Enrollments CRUD panel."""
import tkinter as tk
from tkinter import messagebox
from widgets import StyledButton, StyledCombo, StyledEntry, make_treeview
from theme import *
import database as db


class EnrollmentsPanel(tk.Frame):
    def __init__(self, parent, refresh_counts=None, **kw):
        super().__init__(parent, bg=BG_DARK, **kw)
        self._selected_id = None
        self._student_map = {}
        self._course_map  = {}
        self._teacher_map = {}
        self._build()
        self._load_combos()
        self.load_data()

    def _build(self):
        hdr = tk.Frame(self, bg=BG_DARK)
        hdr.pack(fill="x", padx=30, pady=(20, 10))
        tk.Label(hdr, text="📝  Enrollment Management", font=FONT_TITLE,
                 bg=BG_DARK, fg=TEXT_PRIMARY).pack(side="left")

        form_card = tk.Frame(self, bg=BG_CARD, padx=24, pady=20)
        form_card.pack(fill="x", padx=30, pady=(0, 12))
        tk.Label(form_card, text="Enrollment Details", font=FONT_LABEL_B,
                 bg=BG_CARD, fg=ACCENT).pack(anchor="w", pady=(0, 10))

        row1 = tk.Frame(form_card, bg=BG_CARD)
        row1.pack(fill="x")
        self.c_student  = StyledCombo(row1, "Student *",  width=28)
        self.c_course   = StyledCombo(row1, "Course *",   width=28)
        self.c_teacher  = StyledCombo(row1, "Teacher",    width=28)
        for w in (self.c_student, self.c_course, self.c_teacher):
            w.pack(side="left", padx=(0, 16))

        row2 = tk.Frame(form_card, bg=BG_CARD)
        row2.pack(fill="x", pady=(10, 0))
        self.e_date   = StyledEntry(row2, "Enroll Date (YYYY-MM-DD)", width=22)
        self.e_grade  = StyledEntry(row2, "Grade", width=10)
        self.c_status = StyledCombo(row2, "Status", ("Active", "Completed", "Dropped"), width=16)
        for w in (self.e_date, self.e_grade, self.c_status):
            w.pack(side="left", padx=(0, 16))

        btn_row = tk.Frame(form_card, bg=BG_CARD)
        btn_row.pack(fill="x", pady=(14, 0))
        StyledButton(btn_row, "＋  Enroll",    command=self.add_record,    bg=SUCCESS).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "✎  Update",    command=self.update_record, bg=ACCENT).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "✕  Delete",    command=self.delete_record, bg=DANGER).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "↺  Clear",     command=self.clear_form,    bg=BG_CARD2).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "⟳  Refresh",  command=self._load_combos,  bg=WARNING).pack(side="left")

        tbl, self.tree = make_treeview(
            self,
            ["ID", "Student", "Course", "Teacher", "Date", "Grade", "Status"]
        )
        tbl.pack(fill="both", expand=True, padx=30, pady=(0, 20))
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

    # ── helpers ───────────────────────────────────────────────────────────────

    def _load_combos(self):
        conn = db.get_connection(); cur = db.cursor(conn)
        cur.execute("SELECT id, name FROM students ORDER BY name")
        students = cur.fetchall()
        cur.execute("SELECT id, name FROM courses ORDER BY name")
        courses = cur.fetchall()
        cur.execute("SELECT id, name FROM teachers ORDER BY name")
        teachers = cur.fetchall()
        cur.close(); conn.close()

        self._student_map = {r[1]: r[0] for r in students}
        self._course_map  = {r[1]: r[0] for r in courses}
        self._teacher_map = {r[1]: r[0] for r in teachers}

        self.c_student.set_values(list(self._student_map.keys()))
        self.c_course.set_values(list(self._course_map.keys()))
        self.c_teacher.set_values([""] + list(self._teacher_map.keys()))

    def _resolve(self):
        sname = self.c_student.get()
        cname = self.c_course.get()
        tname = self.c_teacher.get()
        sid = self._student_map.get(sname)
        cid = self._course_map.get(cname)
        tid = self._teacher_map.get(tname)
        return sid, cid, tid

    # ── CRUD ──────────────────────────────────────────────────────────────────

    def add_record(self):
        sid, cid, tid = self._resolve()
        if not sid or not cid:
            messagebox.showwarning("Validation", "Student and Course are required.", parent=self); return
        date   = self.e_date.get().strip() or None
        grade  = self.e_grade.get().strip() or None
        status = self.c_status.get() or "Active"
        p = db.placeholder()
        conn = db.get_connection(); cur = db.cursor(conn)
        try:
            cur.execute(
                f"INSERT INTO enrollments (student_id,course_id,teacher_id,enroll_date,grade,status) "
                f"VALUES ({p},{p},{p},{p},{p},{p})",
                (sid, cid, tid, date, grade, status)
            )
            conn.commit(); self.clear_form(); self.load_data()
            messagebox.showinfo("Success", "Enrollment added.", parent=self)
        except Exception as e:
            conn.rollback(); messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def update_record(self):
        if not self._selected_id:
            messagebox.showwarning("Select", "Select a record first.", parent=self); return
        sid, cid, tid = self._resolve()
        if not sid or not cid:
            messagebox.showwarning("Validation", "Student and Course are required.", parent=self); return
        date   = self.e_date.get().strip() or None
        grade  = self.e_grade.get().strip() or None
        status = self.c_status.get() or "Active"
        p = db.placeholder()
        conn = db.get_connection(); cur = db.cursor(conn)
        try:
            cur.execute(
                f"UPDATE enrollments SET student_id={p},course_id={p},teacher_id={p},"
                f"enroll_date={p},grade={p},status={p} WHERE id={p}",
                (sid, cid, tid, date, grade, status, self._selected_id)
            )
            conn.commit(); self.clear_form(); self.load_data()
            messagebox.showinfo("Success", "Enrollment updated.", parent=self)
        except Exception as e:
            conn.rollback(); messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def delete_record(self):
        if not self._selected_id:
            messagebox.showwarning("Select", "Select a record first.", parent=self); return
        if not messagebox.askyesno("Confirm", "Delete this enrollment?", parent=self): return
        p = db.placeholder()
        conn = db.get_connection(); cur = db.cursor(conn)
        try:
            cur.execute(f"DELETE FROM enrollments WHERE id={p}", (self._selected_id,))
            conn.commit(); self.clear_form(); self.load_data()
        except Exception as e:
            conn.rollback(); messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def load_data(self):
        conn = db.get_connection(); cur = db.cursor(conn)
        cur.execute("""
            SELECT e.id,
                   COALESCE(s.name,'—'),
                   COALESCE(c.name,'—'),
                   COALESCE(t.name,'—'),
                   e.enroll_date,
                   e.grade,
                   e.status
            FROM enrollments e
            LEFT JOIN students s ON e.student_id = s.id
            LEFT JOIN courses  c ON e.course_id  = c.id
            LEFT JOIN teachers t ON e.teacher_id = t.id
            ORDER BY e.id DESC
        """)
        rows = cur.fetchall(); cur.close(); conn.close()
        self.tree.delete(*self.tree.get_children())
        for r in rows:
            self.tree.insert("", "end", values=tuple(r))

    def _on_select(self, _):
        sel = self.tree.selection()
        if not sel: return
        vals = self.tree.item(sel[0])["values"]
        self._selected_id = vals[0]
        self.c_student.set(vals[1])
        self.c_course.set(vals[2])
        self.c_teacher.set(vals[3])
        self.e_date.set(vals[4] or "")
        self.e_grade.set(vals[5] or "")
        self.c_status.set(vals[6] or "")

    def clear_form(self):
        self._selected_id = None
        self.c_student.set(""); self.c_course.set("")
        self.c_teacher.set(""); self.c_status.set("")
        self.e_date.clear(); self.e_grade.clear()

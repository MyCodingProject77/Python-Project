"""
Database configuration and setup for School Management System.
Supports MySQL with automatic fallback to SQLite for portability.
"""

import os
import hashlib

# ── Try MySQL first, fall back to SQLite ──────────────────────────────────────
try:
    import mysql.connector
    DB_BACKEND = "mysql"
except ImportError:
    import sqlite3
    DB_BACKEND = "sqlite"

# ── MySQL connection settings (edit these to match your server) ───────────────
MYSQL_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",        # change if your root has a password
    "database": "school_db",
    "autocommit": False,
}

SQLITE_PATH = os.path.join(os.path.dirname(__file__), "school.db")


# ─────────────────────────────────────────────────────────────────────────────
#  Connection helpers
# ─────────────────────────────────────────────────────────────────────────────

def get_connection():
    """Return a live DB connection (MySQL or SQLite)."""
    if DB_BACKEND == "mysql":
        try:
            conn = mysql.connector.connect(**MYSQL_CONFIG)
            return conn
        except mysql.connector.Error as e:
            # If the schema DB doesn't exist yet, create it first
            if e.errno == 1049:          # Unknown database
                cfg = {k: v for k, v in MYSQL_CONFIG.items() if k != "database"}
                conn = mysql.connector.connect(**cfg)
                cur = conn.cursor()
                cur.execute(f"CREATE DATABASE IF NOT EXISTS {MYSQL_CONFIG['database']}")
                conn.commit()
                cur.close()
                conn.close()
                return mysql.connector.connect(**MYSQL_CONFIG)
            raise
    else:
        conn = sqlite3.connect(SQLITE_PATH)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn


def cursor(conn):
    """Return a cursor; SQLite cursors behave like MySQL ones for basic ops."""
    return conn.cursor()


def placeholder():
    """Return the right parameter placeholder for the active backend."""
    return "%s" if DB_BACKEND == "mysql" else "?"


# ─────────────────────────────────────────────────────────────────────────────
#  Schema initialisation
# ─────────────────────────────────────────────────────────────────────────────

def _sql(mysql_sql: str, sqlite_sql: str = None) -> str:
    """Return the correct SQL variant."""
    if DB_BACKEND == "mysql":
        return mysql_sql
    return sqlite_sql if sqlite_sql is not None else mysql_sql


def initialise_database():
    """Create all tables and seed default admin if they don't exist."""
    conn = get_connection()
    cur = cursor(conn)
    p = placeholder()

    # Admin table
    cur.execute(_sql(
        """CREATE TABLE IF NOT EXISTS admin (
            id       INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50)  NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL
        )""",
        """CREATE TABLE IF NOT EXISTS admin (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )"""
    ))

    # Students
    cur.execute(_sql(
        """CREATE TABLE IF NOT EXISTS students (
            id         INT AUTO_INCREMENT PRIMARY KEY,
            name       VARCHAR(100) NOT NULL,
            email      VARCHAR(100) UNIQUE,
            phone      VARCHAR(20),
            address    TEXT,
            dob        DATE,
            gender     VARCHAR(10),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
        """CREATE TABLE IF NOT EXISTS students (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT NOT NULL,
            email      TEXT UNIQUE,
            phone      TEXT,
            address    TEXT,
            dob        TEXT,
            gender     TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )"""
    ))

    # Courses
    cur.execute(_sql(
        """CREATE TABLE IF NOT EXISTS courses (
            id          INT AUTO_INCREMENT PRIMARY KEY,
            code        VARCHAR(20) NOT NULL UNIQUE,
            name        VARCHAR(100) NOT NULL,
            description TEXT,
            credits     INT DEFAULT 3,
            created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
        """CREATE TABLE IF NOT EXISTS courses (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            code        TEXT NOT NULL UNIQUE,
            name        TEXT NOT NULL,
            description TEXT,
            credits     INTEGER DEFAULT 3,
            created_at  TEXT DEFAULT CURRENT_TIMESTAMP
        )"""
    ))

    # Teachers
    cur.execute(_sql(
        """CREATE TABLE IF NOT EXISTS teachers (
            id         INT AUTO_INCREMENT PRIMARY KEY,
            name       VARCHAR(100) NOT NULL,
            email      VARCHAR(100) UNIQUE,
            phone      VARCHAR(20),
            subject    VARCHAR(100),
            salary     DECIMAL(10,2) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
        """CREATE TABLE IF NOT EXISTS teachers (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT NOT NULL,
            email      TEXT UNIQUE,
            phone      TEXT,
            subject    TEXT,
            salary     REAL DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )"""
    ))

    # Enrollments
    cur.execute(_sql(
        """CREATE TABLE IF NOT EXISTS enrollments (
            id            INT AUTO_INCREMENT PRIMARY KEY,
            student_id    INT NOT NULL,
            course_id     INT NOT NULL,
            teacher_id    INT,
            enroll_date   DATE,
            grade         VARCHAR(5),
            status        VARCHAR(20) DEFAULT 'Active',
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE,
            FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE SET NULL,
            UNIQUE(student_id, course_id)
        )""",
        """CREATE TABLE IF NOT EXISTS enrollments (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id    INTEGER NOT NULL,
            course_id     INTEGER NOT NULL,
            teacher_id    INTEGER,
            enroll_date   TEXT,
            grade         TEXT,
            status        TEXT DEFAULT 'Active',
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE,
            FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE SET NULL,
            UNIQUE(student_id, course_id)
        )"""
    ))

    # Attendance
    cur.execute(_sql(
        """CREATE TABLE IF NOT EXISTS attendance (
            id         INT AUTO_INCREMENT PRIMARY KEY,
            student_id INT NOT NULL,
            course_id  INT NOT NULL,
            date       DATE NOT NULL,
            status     VARCHAR(10) DEFAULT 'Present',
            remarks    TEXT,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE
        )""",
        """CREATE TABLE IF NOT EXISTS attendance (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            course_id  INTEGER NOT NULL,
            date       TEXT NOT NULL,
            status     TEXT DEFAULT 'Present',
            remarks    TEXT,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE
        )"""
    ))

    conn.commit()

    # Seed default admin  (username: admin  /  password: admin123)
    pw_hash = hashlib.sha256("admin123".encode()).hexdigest()
    try:
        cur.execute(
            f"INSERT INTO admin (username, password) VALUES ({p},{p})",
            ("admin", pw_hash)
        )
        conn.commit()
    except Exception:
        conn.rollback()   # already exists – that's fine

    cur.close()
    conn.close()
    return True


# ─────────────────────────────────────────────────────────────────────────────
#  Utility: verify admin login
# ─────────────────────────────────────────────────────────────────────────────

def verify_admin(username: str, password: str) -> bool:
    pw_hash = hashlib.sha256(password.encode()).hexdigest()
    conn = get_connection()
    cur = cursor(conn)
    p = placeholder()
    cur.execute(
        f"SELECT id FROM admin WHERE username={p} AND password={p}",
        (username, pw_hash)
    )
    row = cur.fetchone()
    cur.close()
    conn.close()
    return row is not None


# ─────────────────────────────────────────────────────────────────────────────
#  Dashboard counts
# ─────────────────────────────────────────────────────────────────────────────

def get_counts() -> dict:
    conn = get_connection()
    cur = cursor(conn)
    result = {}
    for key, table in [("students", "students"), ("courses", "courses"), ("teachers", "teachers")]:
        cur.execute(f"SELECT COUNT(*) FROM {table}")
        row = cur.fetchone()
        result[key] = row[0]
    cur.close()
    conn.close()
    return result

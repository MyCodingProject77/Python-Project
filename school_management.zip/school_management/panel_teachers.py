"""Teachers CRUD panel."""
import tkinter as tk
from tkinter import messagebox
from widgets import StyledEntry, StyledButton, make_treeview
from theme import *
import database as db


class TeachersPanel(tk.Frame):
    def __init__(self, parent, refresh_counts, **kw):
        super().__init__(parent, bg=BG_DARK, **kw)
        self.refresh_counts = refresh_counts
        self._selected_id = None
        self._build()
        self.load_data()

    def _build(self):
        hdr = tk.Frame(self, bg=BG_DARK)
        hdr.pack(fill="x", padx=30, pady=(20, 10))
        tk.Label(hdr, text="👨‍🏫  Teacher Management", font=FONT_TITLE,
                 bg=BG_DARK, fg=TEXT_PRIMARY).pack(side="left")

        form_card = tk.Frame(self, bg=BG_CARD, padx=24, pady=20)
        form_card.pack(fill="x", padx=30, pady=(0, 12))
        tk.Label(form_card, text="Teacher Details", font=FONT_LABEL_B,
                 bg=BG_CARD, fg=ACCENT).pack(anchor="w", pady=(0, 10))

        row1 = tk.Frame(form_card, bg=BG_CARD)
        row1.pack(fill="x")
        self.e_name    = StyledEntry(row1, "Full Name *", width=26)
        self.e_email   = StyledEntry(row1, "Email", width=26)
        self.e_phone   = StyledEntry(row1, "Phone", width=18)
        for w in (self.e_name, self.e_email, self.e_phone):
            w.pack(side="left", padx=(0, 16))

        row2 = tk.Frame(form_card, bg=BG_CARD)
        row2.pack(fill="x", pady=(10, 0))
        self.e_subject = StyledEntry(row2, "Subject / Department", width=30)
        self.e_salary  = StyledEntry(row2, "Salary", width=18)
        for w in (self.e_subject, self.e_salary):
            w.pack(side="left", padx=(0, 16))

        btn_row = tk.Frame(form_card, bg=BG_CARD)
        btn_row.pack(fill="x", pady=(14, 0))
        StyledButton(btn_row, "＋  Add Teacher",  command=self.add_record,    bg=SUCCESS).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "✎  Update",        command=self.update_record, bg=ACCENT).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "✕  Delete",        command=self.delete_record, bg=DANGER).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "↺  Clear",         command=self.clear_form,    bg=BG_CARD2).pack(side="left")

        sch = tk.Frame(self, bg=BG_DARK)
        sch.pack(fill="x", padx=30, pady=(0, 8))
        tk.Label(sch, text="🔍 Search:", bg=BG_DARK, fg=TEXT_MUTED,
                 font=FONT_LABEL).pack(side="left")
        self.search_var = tk.StringVar()
        self.search_var.trace("w", lambda *a: self.load_data())
        tk.Entry(sch, textvariable=self.search_var, font=FONT_ENTRY,
                 bg=BG_CARD2, fg=TEXT_PRIMARY, insertbackground=TEXT_PRIMARY,
                 relief="flat", bd=0, highlightthickness=1,
                 highlightbackground=BORDER, highlightcolor=ACCENT,
                 width=36).pack(side="left", padx=8, ipady=5)

        tbl, self.tree = make_treeview(self, ["ID", "Name", "Email", "Phone", "Subject", "Salary"])
        tbl.pack(fill="both", expand=True, padx=30, pady=(0, 20))
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

    def _form_values(self):
        return (
            self.e_name.get().strip(),
            self.e_email.get().strip(),
            self.e_phone.get().strip(),
            self.e_subject.get().strip(),
            self.e_salary.get().strip() or "0",
        )

    def add_record(self):
        name, email, phone, subject, salary = self._form_values()
        if not name:
            messagebox.showwarning("Validation", "Full Name is required.", parent=self); return
        try:
            salary = float(salary)
        except ValueError:
            messagebox.showwarning("Validation", "Salary must be a number.", parent=self); return
        p = db.placeholder()
        conn = db.get_connection(); cur = db.cursor(conn)
        try:
            cur.execute(
                f"INSERT INTO teachers (name,email,phone,subject,salary) VALUES ({p},{p},{p},{p},{p})",
                (name, email, phone, subject, salary)
            )
            conn.commit(); self.clear_form(); self.load_data(); self.refresh_counts()
            messagebox.showinfo("Success", "Teacher added.", parent=self)
        except Exception as e:
            conn.rollback(); messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def update_record(self):
        if not self._selected_id:
            messagebox.showwarning("Select", "Select a teacher first.", parent=self); return
        name, email, phone, subject, salary = self._form_values()
        if not name:
            messagebox.showwarning("Validation", "Full Name is required.", parent=self); return
        try:
            salary = float(salary)
        except ValueError:
            messagebox.showwarning("Validation", "Salary must be a number.", parent=self); return
        p = db.placeholder()
        conn = db.get_connection(); cur = db.cursor(conn)
        try:
            cur.execute(
                f"UPDATE teachers SET name={p},email={p},phone={p},subject={p},salary={p} WHERE id={p}",
                (name, email, phone, subject, salary, self._selected_id)
            )
            conn.commit(); self.clear_form(); self.load_data()
            messagebox.showinfo("Success", "Teacher updated.", parent=self)
        except Exception as e:
            conn.rollback(); messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def delete_record(self):
        if not self._selected_id:
            messagebox.showwarning("Select", "Select a teacher first.", parent=self); return
        if not messagebox.askyesno("Confirm", "Delete this teacher?", parent=self): return
        p = db.placeholder()
        conn = db.get_connection(); cur = db.cursor(conn)
        try:
            cur.execute(f"DELETE FROM teachers WHERE id={p}", (self._selected_id,))
            conn.commit(); self.clear_form(); self.load_data(); self.refresh_counts()
        except Exception as e:
            conn.rollback(); messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def load_data(self):
        q = self.search_var.get().strip() if hasattr(self, "search_var") else ""
        conn = db.get_connection(); cur = db.cursor(conn); p = db.placeholder()
        if q:
            like = f"%{q}%"
            cur.execute(
                f"SELECT id,name,email,phone,subject,salary FROM teachers "
                f"WHERE name LIKE {p} OR email LIKE {p} OR subject LIKE {p}",
                (like, like, like)
            )
        else:
            cur.execute("SELECT id,name,email,phone,subject,salary FROM teachers ORDER BY id DESC")
        rows = cur.fetchall(); cur.close(); conn.close()
        self.tree.delete(*self.tree.get_children())
        for r in rows:
            self.tree.insert("", "end", values=tuple(r))

    def _on_select(self, _):
        sel = self.tree.selection()
        if not sel: return
        vals = self.tree.item(sel[0])["values"]
        self._selected_id = vals[0]
        self.e_name.set(vals[1] or "")
        self.e_email.set(vals[2] or "")
        self.e_phone.set(vals[3] or "")
        self.e_subject.set(vals[4] or "")
        self.e_salary.set(str(vals[5] or ""))

    def clear_form(self):
        self._selected_id = None
        for w in (self.e_name, self.e_email, self.e_phone, self.e_subject, self.e_salary):
            w.clear()

"""
School Management System — Main entry point.
"""
import tkinter as tk
from tkinter import messagebox
import sys, os

sys.path.insert(0, os.path.dirname(__file__))

import database as db
from theme  import *
from widgets import StatCard, StyledButton, StyledEntry


# ═════════════════════════════════════════════════════════════════════════════
#  LOGIN WINDOW
# ═════════════════════════════════════════════════════════════════════════════

class LoginWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("School Management System – Admin Login")
        self.geometry("460x580")
        self.resizable(False, False)
        self.configure(bg=BG_DARK)
        self._center()
        self._build()

    def _center(self):
        self.update_idletasks()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        x  = (sw - 460) // 2
        y  = (sh - 580) // 2
        self.geometry(f"460x580+{x}+{y}")

    def _build(self):
        # Top accent bar
        tk.Frame(self, bg=ACCENT, height=5).pack(fill="x")

        # Icon
        top = tk.Frame(self, bg=BG_DARK)
        top.pack(pady=(30, 0))
        icon_bg = tk.Frame(top, bg=ACCENT, width=80, height=80)
        icon_bg.pack()
        icon_bg.pack_propagate(False)
        tk.Label(icon_bg, text="🏫", font=(FONT_FAMILY, 38),
                 bg=ACCENT, fg="white").place(relx=.5, rely=.5, anchor="center")

        tk.Label(self, text="School Management", font=(FONT_FAMILY, 20, "bold"),
                 bg=BG_DARK, fg=TEXT_PRIMARY).pack(pady=(14, 2))
        tk.Label(self, text="System", font=(FONT_FAMILY, 20, "bold"),
                 bg=BG_DARK, fg=ACCENT).pack()
        tk.Label(self, text="Admin Portal", font=FONT_SUBTITLE,
                 bg=BG_DARK, fg=TEXT_MUTED).pack(pady=(4, 0))

        # ── Form card ─────────────────────────────────────────────────────────
        card = tk.Frame(self, bg=BG_CARD, padx=36, pady=28)
        card.pack(fill="x", padx=40, pady=22)

        tk.Label(card, text="Sign In", font=(FONT_FAMILY, 15, "bold"),
                 bg=BG_CARD, fg=TEXT_PRIMARY).pack(anchor="w", pady=(0, 18))

        # Username
        tk.Label(card, text="USERNAME", bg=BG_CARD, fg=TEXT_MUTED,
                 font=FONT_SMALL).pack(anchor="w")
        self._user_var = tk.StringVar()
        self._user_entry = tk.Entry(
            card, textvariable=self._user_var,
            font=FONT_ENTRY, bg=BG_CARD2, fg=TEXT_PRIMARY,
            insertbackground=TEXT_PRIMARY, relief="flat", bd=0,
            highlightthickness=1, highlightbackground=BORDER,
            highlightcolor=ACCENT
        )
        self._user_entry.pack(fill="x", ipady=9, pady=(3, 14))

        # Password — identical options so it renders the same size
        tk.Label(card, text="PASSWORD", bg=BG_CARD, fg=TEXT_MUTED,
                 font=FONT_SMALL).pack(anchor="w")
        self._pass_var = tk.StringVar()
        self._pass_entry = tk.Entry(
            card, textvariable=self._pass_var, show="•",
            font=FONT_ENTRY, bg=BG_CARD2, fg=TEXT_PRIMARY,
            insertbackground=TEXT_PRIMARY, relief="flat", bd=0,
            highlightthickness=1, highlightbackground=BORDER,
            highlightcolor=ACCENT
        )
        self._pass_entry.pack(fill="x", ipady=9, pady=(3, 0))

        # Error label (always present, empty until needed)
        self._err_var = tk.StringVar()
        tk.Label(card, textvariable=self._err_var,
                 bg=BG_CARD, fg=DANGER, font=FONT_SMALL,
                 wraplength=340, justify="left").pack(anchor="w", pady=(8, 0))

        # ── Real tk.Button for login ───────────────────────────────────────────
        tk.Button(
            card, text="  LOGIN  →",
            command=self._login,
            font=(FONT_FAMILY, 11, "bold"),
            bg=ACCENT, fg="white",
            activebackground=ACCENT_HOVER, activeforeground="white",
            relief="flat", bd=0, cursor="hand2",
            pady=10
        ).pack(fill="x", pady=(14, 0))

        self.bind("<Return>", lambda _: self._login())
        self._user_entry.focus()

        tk.Label(self, text="Default: admin / admin123",
                 bg=BG_DARK, fg=TEXT_MUTED, font=FONT_SMALL).pack(pady=(0, 16))

    def _login(self):
        username = self._user_var.get().strip()
        password = self._pass_var.get()
        if not username or not password:
            self._err_var.set("⚠  Please enter username and password.")
            return
        if db.verify_admin(username, password):
            self.destroy()
            DashboardWindow(username).mainloop()
        else:
            self._err_var.set("✕  Invalid credentials. Please try again.")
            self._pass_var.set("")
            self._pass_entry.focus()


# ═════════════════════════════════════════════════════════════════════════════
#  DASHBOARD WINDOW
# ═════════════════════════════════════════════════════════════════════════════

class DashboardWindow(tk.Tk):
    def __init__(self, admin_name="admin"):
        super().__init__()
        self.title("School Management System")
        self.geometry("1280x780")
        self.minsize(1100, 680)
        self.configure(bg=BG_DARK)
        self._center()
        self._admin_name  = admin_name
        self._panels      = {}
        self._nav_buttons = {}
        self._active_key  = None
        self._stat_cards  = {}

        self._build_shell()
        self.after(50, lambda: self._show_panel("dashboard"))

    def _center(self):
        self.update_idletasks()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        x  = (sw - 1280) // 2
        y  = (sh - 780)  // 2
        self.geometry(f"1280x780+{x}+{y}")

    def _build_shell(self):
        # Top bar
        topbar = tk.Frame(self, bg=BG_CARD, height=56)
        topbar.pack(fill="x", side="top")
        topbar.pack_propagate(False)
        tk.Frame(topbar, bg=ACCENT, width=5).pack(side="left", fill="y")
        tk.Label(topbar, text="  🏫  School Management System",
                 font=(FONT_FAMILY, 15, "bold"),
                 bg=BG_CARD, fg=TEXT_PRIMARY).pack(side="left", padx=8)
        logout_lbl = tk.Label(topbar, text="⏻  Logout",
                              font=FONT_LABEL, bg=BG_CARD, fg=DANGER, cursor="hand2")
        logout_lbl.pack(side="right", padx=16)
        logout_lbl.bind("<Button-1>", self._logout)
        tk.Label(topbar, text=f"👤  {self._admin_name}",
                 font=FONT_LABEL, bg=BG_CARD, fg=TEXT_MUTED).pack(side="right", padx=(0, 4))

        # Body
        body = tk.Frame(self, bg=BG_DARK)
        body.pack(fill="both", expand=True, side="top")
        self._build_sidebar(body)
        self._content = tk.Frame(body, bg=BG_DARK)
        self._content.pack(side="left", fill="both", expand=True)

    def _build_sidebar(self, parent):
        sidebar = tk.Frame(parent, bg=BG_CARD, width=220)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        tk.Label(sidebar, text="NAVIGATION",
                 font=(FONT_FAMILY, 8, "bold"),
                 bg=BG_CARD, fg=TEXT_MUTED).pack(anchor="w", padx=20, pady=(20, 8))

        for icon, label, key in NAV_ITEMS:
            outer = tk.Frame(sidebar, bg=BG_CARD)
            outer.pack(fill="x", pady=1)
            inner = tk.Frame(outer, bg=BG_CARD, padx=20, pady=10)
            inner.pack(fill="x")
            icon_lbl = tk.Label(inner, text=icon, font=(FONT_FAMILY, 14),
                                bg=BG_CARD, fg=TEXT_MUTED)
            icon_lbl.pack(side="left")
            text_lbl = tk.Label(inner, text=f"  {label}", font=FONT_NAV,
                                bg=BG_CARD, fg=TEXT_MUTED)
            text_lbl.pack(side="left")

            for w in (outer, inner, icon_lbl, text_lbl):
                w.config(cursor="hand2")
                w.bind("<Button-1>", lambda e, k=key: self._show_panel(k))
                w.bind("<Enter>",    lambda e, o=outer, i=inner, il=icon_lbl, tl=text_lbl:
                       self._hover_on(o, i, il, tl))
                w.bind("<Leave>",    lambda e, k2=key, o=outer, i=inner, il=icon_lbl, tl=text_lbl:
                       self._hover_off(k2, o, i, il, tl))

            self._nav_buttons[key] = (outer, inner, icon_lbl, text_lbl)

        tk.Frame(sidebar, bg=BORDER, height=1).pack(fill="x", padx=20, pady=20)
        tk.Label(sidebar, text="v1.0.0", font=FONT_SMALL,
                 bg=BG_CARD, fg=TEXT_MUTED).pack(side="bottom", pady=12)

    def _hover_on(self, outer, inner, icon_lbl, text_lbl):
        if self._active_key:
            act = self._nav_buttons.get(self._active_key)
            if act and outer is act[0]:
                return
        outer.config(bg="#2D3748")
        inner.config(bg="#2D3748")
        icon_lbl.config(bg="#2D3748")
        text_lbl.config(bg="#2D3748")

    def _hover_off(self, key, outer, inner, icon_lbl, text_lbl):
        if key == self._active_key:
            return
        outer.config(bg=BG_CARD)
        inner.config(bg=BG_CARD)
        icon_lbl.config(bg=BG_CARD, fg=TEXT_MUTED)
        text_lbl.config(bg=BG_CARD, fg=TEXT_MUTED)

    def _show_panel(self, key):
        if self._active_key and self._active_key in self._panels:
            self._panels[self._active_key].pack_forget()

        # deactivate all nav buttons (Frames only take bg; Labels take bg+fg)
        for k, (o, i, il, tl) in self._nav_buttons.items():
            o.config(bg=BG_CARD)
            i.config(bg=BG_CARD)
            il.config(bg=BG_CARD, fg=TEXT_MUTED)
            tl.config(bg=BG_CARD, fg=TEXT_MUTED)

        # activate clicked nav button
        if key in self._nav_buttons:
            o, i, il, tl = self._nav_buttons[key]
            o.config(bg=ACCENT)
            i.config(bg=ACCENT)
            il.config(bg=ACCENT, fg="white")
            tl.config(bg=ACCENT, fg="white")

        self._active_key = key

        if key not in self._panels:
            self._panels[key] = self._create_panel(key)

        self._panels[key].pack(fill="both", expand=True)

        if key == "dashboard":
            self.after(10, self._refresh_counts)

    def _create_panel(self, key):
        from panel_students    import StudentsPanel
        from panel_courses     import CoursesPanel
        from panel_teachers    import TeachersPanel
        from panel_enrollments import EnrollmentsPanel
        from panel_attendance  import AttendancePanel

        mapping = {
            "dashboard":   lambda: self._build_dashboard_panel(),
            "students":    lambda: StudentsPanel(self._content, self._refresh_counts),
            "courses":     lambda: CoursesPanel(self._content, self._refresh_counts),
            "teachers":    lambda: TeachersPanel(self._content, self._refresh_counts),
            "enrollments": lambda: EnrollmentsPanel(self._content),
            "attendance":  lambda: AttendancePanel(self._content),
        }
        builder = mapping.get(key)
        return builder() if builder else tk.Frame(self._content, bg=BG_DARK)

    def _build_dashboard_panel(self):
        frame = tk.Frame(self._content, bg=BG_DARK)

        hdr = tk.Frame(frame, bg=BG_DARK)
        hdr.pack(fill="x", padx=30, pady=(28, 18))
        tk.Label(hdr, text=f"Welcome back, {self._admin_name} 👋",
                 font=(FONT_FAMILY, 22, "bold"),
                 bg=BG_DARK, fg=TEXT_PRIMARY).pack(side="left")
        from datetime import datetime
        tk.Label(hdr, text=datetime.now().strftime("%A, %d %B %Y"),
                 font=FONT_LABEL, bg=BG_DARK, fg=TEXT_MUTED).pack(side="right")

        cards_row = tk.Frame(frame, bg=BG_DARK)
        cards_row.pack(fill="x", padx=30, pady=(0, 28))
        card_specs = [
            ("Total Students", "👨‍🎓", STAT_COLORS[0], "students"),
            ("Total Courses",  "📚",  STAT_COLORS[1], "courses"),
            ("Total Teachers", "👨‍🏫", STAT_COLORS[2], "teachers"),
        ]
        self._stat_cards = {}
        for title, icon, color, ckey in card_specs:
            card = StatCard(cards_row, title, icon, color)
            card.pack(side="left", fill="x", expand=True, padx=(0, 16), ipady=8)
            self._stat_cards[ckey] = card

        tk.Label(frame, text="Quick Access",
                 font=(FONT_FAMILY, 14, "bold"),
                 bg=BG_DARK, fg=TEXT_PRIMARY).pack(padx=30, anchor="w")

        tiles_row = tk.Frame(frame, bg=BG_DARK)
        tiles_row.pack(fill="x", padx=30, pady=(12, 28))

        tile_specs = [
            ("👨‍🎓", "Students",    "students",    ACCENT),
            ("📚",  "Courses",     "courses",     ACCENT2),
            ("👨‍🏫", "Teachers",    "teachers",    SUCCESS),
            ("📝",  "Enrollments", "enrollments", WARNING),
            ("📅",  "Attendance",  "attendance",  DANGER),
        ]
        for icon, lbl, nav_key, color in tile_specs:
            tile = tk.Frame(tiles_row, bg=BG_CARD, padx=22, pady=18, cursor="hand2")
            tile.pack(side="left", padx=(0, 12))
            tk.Label(tile, text=icon, font=(FONT_FAMILY, 28),
                     bg=BG_CARD, fg=color).pack()
            tk.Label(tile, text=lbl, font=FONT_NAV,
                     bg=BG_CARD, fg=TEXT_PRIMARY).pack(pady=(4, 0))
            tk.Frame(tile, bg=color, height=3).pack(fill="x", pady=(8, 0))

            def _make_nav(k):
                def _go(e=None): self._show_panel(k)
                return _go

            go = _make_nav(nav_key)
            tile.bind("<Button-1>", go)
            tile.bind("<Enter>",    lambda e, t=tile, c=color: t.config(bg=c))
            tile.bind("<Leave>",    lambda e, t=tile: t.config(bg=BG_CARD))
            for child in tile.winfo_children():
                child.bind("<Button-1>", go)
                child.bind("<Enter>",    lambda e, t=tile, c=color: t.config(bg=c))
                child.bind("<Leave>",    lambda e, t=tile: t.config(bg=BG_CARD))

        banner = tk.Frame(frame, bg=BG_CARD, padx=24, pady=16)
        banner.pack(fill="x", padx=30)
        tk.Label(banner, text="ℹ  System Info",
                 font=FONT_LABEL_B, bg=BG_CARD, fg=ACCENT).pack(anchor="w")
        tk.Label(banner,
                 text=("•  Default login: admin / admin123\n"
                       "•  Click any row in a table to load it into the edit form.\n"
                       "•  Dashboard counts update automatically after every Add / Delete.\n"
                       "•  Use ⟳ Refresh in Enrollment & Attendance after adding new students/courses."),
                 font=FONT_LABEL, bg=BG_CARD, fg=TEXT_MUTED,
                 justify="left").pack(anchor="w", pady=(6, 0))

        return frame

    def _refresh_counts(self):
        if not self._stat_cards:
            return
        try:
            counts = db.get_counts()
            for ckey, card in self._stat_cards.items():
                card.set_count(counts.get(ckey, 0))
        except Exception:
            pass

    def _logout(self, _=None):
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            self.destroy()
            LoginWindow().mainloop()


# ═════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ═════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    try:
        db.initialise_database()
    except Exception as e:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Database Error",
                             f"Could not initialise database:\n\n{e}", parent=root)
        root.destroy()

    LoginWindow().mainloop()

"""
Visual theme constants for School Management System.
"""

# ── Palette ───────────────────────────────────────────────────────────────────
BG_DARK       = "#0F172A"   # app background
BG_CARD       = "#1E293B"   # sidebar / card surfaces
BG_CARD2      = "#162032"   # slightly different card
ACCENT        = "#6366F1"   # indigo – primary accent
ACCENT_HOVER  = "#4F46E5"
ACCENT2       = "#06B6D4"   # cyan  – secondary accent
SUCCESS       = "#10B981"   # green
WARNING       = "#F59E0B"   # amber
DANGER        = "#EF4444"   # red
TEXT_PRIMARY  = "#F1F5F9"
TEXT_MUTED    = "#94A3B8"
BORDER        = "#334155"

# Stat-card colours
STAT_COLORS = ["#6366F1", "#06B6D4", "#10B981"]

# ── Fonts ─────────────────────────────────────────────────────────────────────
FONT_FAMILY   = "Segoe UI"
FONT_TITLE    = (FONT_FAMILY, 22, "bold")
FONT_SUBTITLE = (FONT_FAMILY, 13)
FONT_LABEL    = (FONT_FAMILY, 11)
FONT_LABEL_B  = (FONT_FAMILY, 11, "bold")
FONT_SMALL    = (FONT_FAMILY, 9)
FONT_LARGE_B  = (FONT_FAMILY, 28, "bold")
FONT_NAV      = (FONT_FAMILY, 12, "bold")
FONT_NAV_SUB  = (FONT_FAMILY, 10)
FONT_BTN      = (FONT_FAMILY, 10, "bold")
FONT_ENTRY    = (FONT_FAMILY, 11)

# ── Sidebar nav items ─────────────────────────────────────────────────────────
NAV_ITEMS = [
    ("🏠", "Dashboard",   "dashboard"),
    ("👨‍🎓", "Students",    "students"),
    ("📚", "Courses",     "courses"),
    ("👨‍🏫", "Teachers",    "teachers"),
    ("📝", "Enrollments", "enrollments"),
    ("📅", "Attendance",  "attendance"),
]

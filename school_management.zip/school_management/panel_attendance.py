"""Attendance CRUD panel."""
import tkinter as tk
from tkinter import messagebox
from datetime import date as dt_date
from widgets import StyledButton, StyledCombo, StyledEntry, make_treeview
from theme import *
import database as db


class AttendancePanel(tk.Frame):
    def __init__(self, parent, refresh_counts=None, **kw):
        super().__init__(parent, bg=BG_DARK, **kw)
        self._selected_id = None
        self._student_map = {}
        self._course_map  = {}
        self._build()
        self._load_combos()
        self.load_data()

    def _build(self):
        hdr = tk.Frame(self, bg=BG_DARK)
        hdr.pack(fill="x", padx=30, pady=(20, 10))
        tk.Label(hdr, text="📅  Attendance Management", font=FONT_TITLE,
                 bg=BG_DARK, fg=TEXT_PRIMARY).pack(side="left")

        form_card = tk.Frame(self, bg=BG_CARD, padx=24, pady=20)
        form_card.pack(fill="x", padx=30, pady=(0, 12))
        tk.Label(form_card, text="Attendance Details", font=FONT_LABEL_B,
                 bg=BG_CARD, fg=ACCENT).pack(anchor="w", pady=(0, 10))

        row1 = tk.Frame(form_card, bg=BG_CARD)
        row1.pack(fill="x")
        self.c_student = StyledCombo(row1, "Student *", width=28)
        self.c_course  = StyledCombo(row1, "Course *",  width=28)
        self.e_date    = StyledEntry(row1, "Date (YYYY-MM-DD) *", width=22)
        self.e_date.set(str(dt_date.today()))
        for w in (self.c_student, self.c_course, self.e_date):
            w.pack(side="left", padx=(0, 16))

        row2 = tk.Frame(form_card, bg=BG_CARD)
        row2.pack(fill="x", pady=(10, 0))
        self.c_status  = StyledCombo(row2, "Status", ("Present", "Absent", "Late", "Excused"), width=14)
        self.c_status.set("Present")
        self.e_remarks = StyledEntry(row2, "Remarks", width=50)
        for w in (self.c_status, self.e_remarks):
            w.pack(side="left", padx=(0, 16))

        btn_row = tk.Frame(form_card, bg=BG_CARD)
        btn_row.pack(fill="x", pady=(14, 0))
        StyledButton(btn_row, "＋  Mark Attendance", command=self.add_record,    bg=SUCCESS).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "✎  Update",           command=self.update_record, bg=ACCENT).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "✕  Delete",           command=self.delete_record, bg=DANGER).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "↺  Clear",            command=self.clear_form,    bg=BG_CARD2).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "⟳  Refresh",         command=self._load_combos,  bg=WARNING).pack(side="left")

        # Summary bar
        self._summary_var = tk.StringVar(value="")
        tk.Label(self, textvariable=self._summary_var, bg=BG_DARK,
                 fg=ACCENT2, font=FONT_LABEL_B).pack(padx=30, anchor="w")

        tbl, self.tree = make_treeview(
            self,
            ["ID", "Student", "Course", "Date", "Status", "Remarks"]
        )
        tbl.pack(fill="both", expand=True, padx=30, pady=(4, 20))
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

    def _load_combos(self):
        conn = db.get_connection(); cur = db.cursor(conn)
        cur.execute("SELECT id,name FROM students ORDER BY name")
        self._student_map = {r[1]: r[0] for r in cur.fetchall()}
        cur.execute("SELECT id,name FROM courses ORDER BY name")
        self._course_map  = {r[1]: r[0] for r in cur.fetchall()}
        cur.close(); conn.close()
        self.c_student.set_values(list(self._student_map.keys()))
        self.c_course.set_values(list(self._course_map.keys()))

    def _resolve(self):
        sid = self._student_map.get(self.c_student.get())
        cid = self._course_map.get(self.c_course.get())
        return sid, cid

    def add_record(self):
        sid, cid = self._resolve()
        if not sid or not cid:
            messagebox.showwarning("Validation", "Student and Course are required.", parent=self); return
        date    = self.e_date.get().strip()
        status  = self.c_status.get() or "Present"
        remarks = self.e_remarks.get().strip()
        if not date:
            messagebox.showwarning("Validation", "Date is required.", parent=self); return
        p = db.placeholder()
        conn = db.get_connection(); cur = db.cursor(conn)
        try:
            cur.execute(
                f"INSERT INTO attendance (student_id,course_id,date,status,remarks) "
                f"VALUES ({p},{p},{p},{p},{p})",
                (sid, cid, date, status, remarks)
            )
            conn.commit(); self.clear_form(); self.load_data()
            messagebox.showinfo("Success", "Attendance recorded.", parent=self)
        except Exception as e:
            conn.rollback(); messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def update_record(self):
        if not self._selected_id:
            messagebox.showwarning("Select", "Select a record first.", parent=self); return
        sid, cid = self._resolve()
        if not sid or not cid:
            messagebox.showwarning("Validation", "Student and Course are required.", parent=self); return
        date    = self.e_date.get().strip()
        status  = self.c_status.get() or "Present"
        remarks = self.e_remarks.get().strip()
        p = db.placeholder()
        conn = db.get_connection(); cur = db.cursor(conn)
        try:
            cur.execute(
                f"UPDATE attendance SET student_id={p},course_id={p},date={p},"
                f"status={p},remarks={p} WHERE id={p}",
                (sid, cid, date, status, remarks, self._selected_id)
            )
            conn.commit(); self.clear_form(); self.load_data()
            messagebox.showinfo("Success", "Attendance updated.", parent=self)
        except Exception as e:
            conn.rollback(); messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def delete_record(self):
        if not self._selected_id:
            messagebox.showwarning("Select", "Select a record first.", parent=self); return
        if not messagebox.askyesno("Confirm", "Delete this record?", parent=self): return
        p = db.placeholder()
        conn = db.get_connection(); cur = db.cursor(conn)
        try:
            cur.execute(f"DELETE FROM attendance WHERE id={p}", (self._selected_id,))
            conn.commit(); self.clear_form(); self.load_data()
        except Exception as e:
            conn.rollback(); messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def load_data(self):
        conn = db.get_connection(); cur = db.cursor(conn)
        cur.execute("""
            SELECT a.id,
                   COALESCE(s.name,'—'),
                   COALESCE(c.name,'—'),
                   a.date, a.status, a.remarks
            FROM attendance a
            LEFT JOIN students s ON a.student_id = s.id
            LEFT JOIN courses  c ON a.course_id  = c.id
            ORDER BY a.date DESC, a.id DESC
        """)
        rows = cur.fetchall()

        # summary
        cur.execute("SELECT status, COUNT(*) FROM attendance GROUP BY status")
        summary = {r[0]: r[1] for r in cur.fetchall()}
        cur.close(); conn.close()

        self.tree.delete(*self.tree.get_children())
        for r in rows:
            tag = r[4].lower() if r[4] else ""
            self.tree.insert("", "end", values=tuple(r), tags=(tag,))
        self.tree.tag_configure("absent", foreground=DANGER)
        self.tree.tag_configure("late",   foreground=WARNING)
        self.tree.tag_configure("present",foreground=SUCCESS)

        parts = [f"{v} {k}" for k, v in summary.items()]
        self._summary_var.set("  ·  ".join(parts) if parts else "")

    def _on_select(self, _):
        sel = self.tree.selection()
        if not sel: return
        vals = self.tree.item(sel[0])["values"]
        self._selected_id = vals[0]
        self.c_student.set(vals[1]); self.c_course.set(vals[2])
        self.e_date.set(vals[3] or ""); self.c_status.set(vals[4] or "")
        self.e_remarks.set(vals[5] or "")

    def clear_form(self):
        self._selected_id = None
        self.c_student.set(""); self.c_course.set("")
        self.c_status.set("Present")
        self.e_date.set(str(dt_date.today()))
        self.e_remarks.clear()

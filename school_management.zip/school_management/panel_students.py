"""Students CRUD panel."""
import tkinter as tk
from tkinter import messagebox
from widgets import StyledEntry, StyledButton, StyledCombo, make_treeview, hsep
from theme import *
import database as db


class StudentsPanel(tk.Frame):
    def __init__(self, parent, refresh_counts, **kw):
        super().__init__(parent, bg=BG_DARK, **kw)
        self.refresh_counts = refresh_counts
        self._selected_id = None
        self._build()
        self.load_data()

    # ── layout ────────────────────────────────────────────────────────────────

    def _build(self):
        # Title row
        hdr = tk.Frame(self, bg=BG_DARK)
        hdr.pack(fill="x", padx=30, pady=(20, 10))
        tk.Label(hdr, text="👨‍🎓  Student Management", font=FONT_TITLE,
                 bg=BG_DARK, fg=TEXT_PRIMARY).pack(side="left")

        # Form card
        form_card = tk.Frame(self, bg=BG_CARD, padx=24, pady=20)
        form_card.pack(fill="x", padx=30, pady=(0, 12))

        tk.Label(form_card, text="Student Details", font=FONT_LABEL_B,
                 bg=BG_CARD, fg=ACCENT).pack(anchor="w", pady=(0, 10))

        row1 = tk.Frame(form_card, bg=BG_CARD)
        row1.pack(fill="x")
        self.e_name   = StyledEntry(row1, "Full Name *", width=26)
        self.e_email  = StyledEntry(row1, "Email Address", width=26)
        self.e_phone  = StyledEntry(row1, "Phone", width=22)
        for w in (self.e_name, self.e_email, self.e_phone):
            w.pack(side="left", padx=(0, 16), fill="x")

        row2 = tk.Frame(form_card, bg=BG_CARD)
        row2.pack(fill="x", pady=(10, 0))
        self.e_dob     = StyledEntry(row2, "Date of Birth (YYYY-MM-DD)", width=22)
        self.e_gender  = StyledCombo(row2, "Gender", ("Male", "Female", "Other"), width=14)
        self.e_address = StyledEntry(row2, "Address", width=42)
        for w in (self.e_dob, self.e_gender, self.e_address):
            w.pack(side="left", padx=(0, 16))

        # Action buttons
        btn_row = tk.Frame(form_card, bg=BG_CARD)
        btn_row.pack(fill="x", pady=(14, 0))
        StyledButton(btn_row, "＋  Add Student",    command=self.add_record,    bg=SUCCESS).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "✎  Update",          command=self.update_record, bg=ACCENT).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "✕  Delete",          command=self.delete_record, bg=DANGER).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "↺  Clear",           command=self.clear_form,    bg=BG_CARD2).pack(side="left")

        # Search bar
        sch = tk.Frame(self, bg=BG_DARK)
        sch.pack(fill="x", padx=30, pady=(0, 8))
        tk.Label(sch, text="🔍 Search:", bg=BG_DARK, fg=TEXT_MUTED,
                 font=FONT_LABEL).pack(side="left")
        self.search_var = tk.StringVar()
        self.search_var.trace("w", lambda *a: self.load_data())
        tk.Entry(sch, textvariable=self.search_var, font=FONT_ENTRY,
                 bg=BG_CARD2, fg=TEXT_PRIMARY, insertbackground=TEXT_PRIMARY,
                 relief="flat", bd=0, highlightthickness=1,
                 highlightbackground=BORDER, highlightcolor=ACCENT,
                 width=36).pack(side="left", padx=8, ipady=5)

        # Table
        tbl_frame, self.tree = make_treeview(
            self,
            ["ID", "Name", "Email", "Phone", "DOB", "Gender", "Address"]
        )
        tbl_frame.pack(fill="both", expand=True, padx=30, pady=(0, 20))
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

    # ── CRUD ──────────────────────────────────────────────────────────────────

    def _form_values(self):
        return (
            self.e_name.get().strip(),
            self.e_email.get().strip(),
            self.e_phone.get().strip(),
            self.e_address.get().strip(),
            self.e_dob.get().strip(),
            self.e_gender.get(),
        )

    def add_record(self):
        name, email, phone, address, dob, gender = self._form_values()
        if not name:
            messagebox.showwarning("Validation", "Full Name is required.", parent=self)
            return
        p = db.placeholder()
        conn = db.get_connection()
        cur = db.cursor(conn)
        try:
            cur.execute(
                f"INSERT INTO students (name,email,phone,address,dob,gender) "
                f"VALUES ({p},{p},{p},{p},{p},{p})",
                (name, email, phone, address, dob or None, gender)
            )
            conn.commit()
            self.clear_form(); self.load_data(); self.refresh_counts()
            messagebox.showinfo("Success", "Student added successfully.", parent=self)
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def update_record(self):
        if not self._selected_id:
            messagebox.showwarning("Select", "Please select a student to update.", parent=self)
            return
        name, email, phone, address, dob, gender = self._form_values()
        if not name:
            messagebox.showwarning("Validation", "Full Name is required.", parent=self)
            return
        p = db.placeholder()
        conn = db.get_connection()
        cur = db.cursor(conn)
        try:
            cur.execute(
                f"UPDATE students SET name={p},email={p},phone={p},"
                f"address={p},dob={p},gender={p} WHERE id={p}",
                (name, email, phone, address, dob or None, gender, self._selected_id)
            )
            conn.commit()
            self.clear_form(); self.load_data()
            messagebox.showinfo("Success", "Student updated.", parent=self)
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def delete_record(self):
        if not self._selected_id:
            messagebox.showwarning("Select", "Please select a student to delete.", parent=self)
            return
        if not messagebox.askyesno("Confirm", "Delete this student?", parent=self):
            return
        p = db.placeholder()
        conn = db.get_connection()
        cur = db.cursor(conn)
        try:
            cur.execute(f"DELETE FROM students WHERE id={p}", (self._selected_id,))
            conn.commit()
            self.clear_form(); self.load_data(); self.refresh_counts()
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def load_data(self):
        q = self.search_var.get().strip() if hasattr(self, "search_var") else ""
        conn = db.get_connection()
        cur = db.cursor(conn)
        p = db.placeholder()
        if q:
            like = f"%{q}%"
            cur.execute(
                f"SELECT id,name,email,phone,dob,gender,address FROM students "
                f"WHERE name LIKE {p} OR email LIKE {p} OR phone LIKE {p}",
                (like, like, like)
            )
        else:
            cur.execute("SELECT id,name,email,phone,dob,gender,address FROM students ORDER BY id DESC")
        rows = cur.fetchall()
        cur.close(); conn.close()
        self.tree.delete(*self.tree.get_children())
        for r in rows:
            self.tree.insert("", "end", values=tuple(r))

    def _on_select(self, _):
        sel = self.tree.selection()
        if not sel:
            return
        vals = self.tree.item(sel[0])["values"]
        self._selected_id = vals[0]
        self.e_name.set(vals[1] or "")
        self.e_email.set(vals[2] or "")
        self.e_phone.set(vals[3] or "")
        self.e_dob.set(vals[4] or "")
        self.e_gender.set(vals[5] or "")
        self.e_address.set(vals[6] or "")

    def clear_form(self):
        self._selected_id = None
        for w in (self.e_name, self.e_email, self.e_phone, self.e_dob, self.e_address):
            w.clear()
        self.e_gender.set("")

"""Courses CRUD panel."""
import tkinter as tk
from tkinter import messagebox
from widgets import StyledEntry, StyledButton, make_treeview
from theme import *
import database as db


class CoursesPanel(tk.Frame):
    def __init__(self, parent, refresh_counts, **kw):
        super().__init__(parent, bg=BG_DARK, **kw)
        self.refresh_counts = refresh_counts
        self._selected_id = None
        self._build()
        self.load_data()

    def _build(self):
        hdr = tk.Frame(self, bg=BG_DARK)
        hdr.pack(fill="x", padx=30, pady=(20, 10))
        tk.Label(hdr, text="📚  Course Management", font=FONT_TITLE,
                 bg=BG_DARK, fg=TEXT_PRIMARY).pack(side="left")

        form_card = tk.Frame(self, bg=BG_CARD, padx=24, pady=20)
        form_card.pack(fill="x", padx=30, pady=(0, 12))
        tk.Label(form_card, text="Course Details", font=FONT_LABEL_B,
                 bg=BG_CARD, fg=ACCENT).pack(anchor="w", pady=(0, 10))

        row1 = tk.Frame(form_card, bg=BG_CARD)
        row1.pack(fill="x")
        self.e_code    = StyledEntry(row1, "Course Code *", width=16)
        self.e_name    = StyledEntry(row1, "Course Name *", width=34)
        self.e_credits = StyledEntry(row1, "Credits", width=10)
        for w in (self.e_code, self.e_name, self.e_credits):
            w.pack(side="left", padx=(0, 16))

        row2 = tk.Frame(form_card, bg=BG_CARD)
        row2.pack(fill="x", pady=(10, 0))
        self.e_desc = StyledEntry(row2, "Description", width=70)
        self.e_desc.pack(side="left")

        btn_row = tk.Frame(form_card, bg=BG_CARD)
        btn_row.pack(fill="x", pady=(14, 0))
        StyledButton(btn_row, "＋  Add Course",  command=self.add_record,    bg=SUCCESS).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "✎  Update",       command=self.update_record, bg=ACCENT).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "✕  Delete",       command=self.delete_record, bg=DANGER).pack(side="left", padx=(0, 8))
        StyledButton(btn_row, "↺  Clear",        command=self.clear_form,    bg=BG_CARD2).pack(side="left")

        # Search
        sch = tk.Frame(self, bg=BG_DARK)
        sch.pack(fill="x", padx=30, pady=(0, 8))
        tk.Label(sch, text="🔍 Search:", bg=BG_DARK, fg=TEXT_MUTED,
                 font=FONT_LABEL).pack(side="left")
        self.search_var = tk.StringVar()
        self.search_var.trace("w", lambda *a: self.load_data())
        tk.Entry(sch, textvariable=self.search_var, font=FONT_ENTRY,
                 bg=BG_CARD2, fg=TEXT_PRIMARY, insertbackground=TEXT_PRIMARY,
                 relief="flat", bd=0, highlightthickness=1,
                 highlightbackground=BORDER, highlightcolor=ACCENT,
                 width=36).pack(side="left", padx=8, ipady=5)

        tbl, self.tree = make_treeview(self, ["ID", "Code", "Name", "Credits", "Description"])
        tbl.pack(fill="both", expand=True, padx=30, pady=(0, 20))
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

    def _form_values(self):
        return (
            self.e_code.get().strip(),
            self.e_name.get().strip(),
            self.e_desc.get().strip(),
            self.e_credits.get().strip() or "3",
        )

    def add_record(self):
        code, name, desc, credits = self._form_values()
        if not code or not name:
            messagebox.showwarning("Validation", "Code and Name are required.", parent=self); return
        try:
            credits = int(credits)
        except ValueError:
            messagebox.showwarning("Validation", "Credits must be a number.", parent=self); return
        p = db.placeholder()
        conn = db.get_connection(); cur = db.cursor(conn)
        try:
            cur.execute(
                f"INSERT INTO courses (code,name,description,credits) VALUES ({p},{p},{p},{p})",
                (code, name, desc, credits)
            )
            conn.commit()
            self.clear_form(); self.load_data(); self.refresh_counts()
            messagebox.showinfo("Success", "Course added.", parent=self)
        except Exception as e:
            conn.rollback(); messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def update_record(self):
        if not self._selected_id:
            messagebox.showwarning("Select", "Select a course first.", parent=self); return
        code, name, desc, credits = self._form_values()
        if not code or not name:
            messagebox.showwarning("Validation", "Code and Name are required.", parent=self); return
        try:
            credits = int(credits)
        except ValueError:
            messagebox.showwarning("Validation", "Credits must be a number.", parent=self); return
        p = db.placeholder()
        conn = db.get_connection(); cur = db.cursor(conn)
        try:
            cur.execute(
                f"UPDATE courses SET code={p},name={p},description={p},credits={p} WHERE id={p}",
                (code, name, desc, credits, self._selected_id)
            )
            conn.commit(); self.clear_form(); self.load_data()
            messagebox.showinfo("Success", "Course updated.", parent=self)
        except Exception as e:
            conn.rollback(); messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def delete_record(self):
        if not self._selected_id:
            messagebox.showwarning("Select", "Select a course first.", parent=self); return
        if not messagebox.askyesno("Confirm", "Delete this course?", parent=self): return
        p = db.placeholder()
        conn = db.get_connection(); cur = db.cursor(conn)
        try:
            cur.execute(f"DELETE FROM courses WHERE id={p}", (self._selected_id,))
            conn.commit(); self.clear_form(); self.load_data(); self.refresh_counts()
        except Exception as e:
            conn.rollback(); messagebox.showerror("Error", str(e), parent=self)
        finally:
            cur.close(); conn.close()

    def load_data(self):
        q = self.search_var.get().strip() if hasattr(self, "search_var") else ""
        conn = db.get_connection(); cur = db.cursor(conn); p = db.placeholder()
        if q:
            like = f"%{q}%"
            cur.execute(
                f"SELECT id,code,name,credits,description FROM courses "
                f"WHERE name LIKE {p} OR code LIKE {p}", (like, like)
            )
        else:
            cur.execute("SELECT id,code,name,credits,description FROM courses ORDER BY id DESC")
        rows = cur.fetchall(); cur.close(); conn.close()
        self.tree.delete(*self.tree.get_children())
        for r in rows:
            self.tree.insert("", "end", values=tuple(r))

    def _on_select(self, _):
        sel = self.tree.selection()
        if not sel: return
        vals = self.tree.item(sel[0])["values"]
        self._selected_id = vals[0]
        self.e_code.set(vals[1] or "")
        self.e_name.set(vals[2] or "")
        self.e_credits.set(vals[3] or "")
        self.e_desc.set(vals[4] or "")

    def clear_form(self):
        self._selected_id = None
        for w in (self.e_code, self.e_name, self.e_credits, self.e_desc):
            w.clear()

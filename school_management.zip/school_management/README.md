# 🏫 School Management System

A professional desktop application built with **Python + Tkinter** and **MySQL** (SQLite fallback).

---

## ✅ Features

- **Admin Login** with SHA-256 hashed password
- **Dashboard** with live stats (Total Students, Courses, Teachers)
- **5 Modules** with full CRUD:
  - 👨‍🎓 Students
  - 📚 Courses
  - 👨‍🏫 Teachers
  - 📝 Enrollments
  - 📅 Attendance
- Search/filter in every table
- Professional dark UI (no third-party UI library needed)
- Works with **MySQL** or automatically falls back to **SQLite**

---

## 🚀 Quick Start

### 1. Requirements

```bash
pip install mysql-connector-python
```

> If `mysql-connector-python` is not installed, the app uses **SQLite** automatically — no extra setup needed.

### 2. MySQL Setup (optional)

Edit `database.py` and update:

```python
MYSQL_CONFIG = {
    "host":     "localhost",
    "user":     "root",
    "password": "your_password",   # ← change this
    "database": "school_db",
}
```

The app will create the `school_db` database and all tables automatically on first run.

### 3. Run the App

```bash
cd school_management
python main.py
```

---

## 🔑 Default Login

| Field    | Value      |
|----------|------------|
| Username | `admin`    |
| Password | `admin123` |

---

## 📁 File Structure

```
school_management/
├── main.py              # Entry point — Login + Dashboard
├── database.py          # DB connection, schema init, helpers
├── theme.py             # Colours, fonts, constants
├── widgets.py           # Reusable styled widgets
├── panel_students.py    # Students CRUD panel
├── panel_courses.py     # Courses CRUD panel
├── panel_teachers.py    # Teachers CRUD panel
├── panel_enrollments.py # Enrollments CRUD panel
├── panel_attendance.py  # Attendance CRUD panel
└── school.db            # Auto-created SQLite file (if no MySQL)
```

---

## 🎨 UI Theme

The app uses a custom dark theme built entirely with `tkinter`:
- Background: `#0F172A`
- Accent: `#6366F1` (Indigo)
- Cards: `#1E293B`
- Success: `#10B981`, Warning: `#F59E0B`, Danger: `#EF4444`

---

## 📊 Database Schema

| Table        | Key Fields                                      |
|--------------|-------------------------------------------------|
| `admin`      | id, username, password (SHA-256)                |
| `students`   | id, name, email, phone, dob, gender, address    |
| `courses`    | id, code, name, description, credits            |
| `teachers`   | id, name, email, phone, subject, salary         |
| `enrollments`| id, student_id, course_id, teacher_id, grade   |
| `attendance` | id, student_id, course_id, date, status         |

---

## 💡 Tips

- Click any row in a table to load it into the form for editing
- Use the **⟳ Refresh** button in Enrollment/Attendance after adding new students or courses
- Dashboard counters update automatically after every Add/Delete
- Press **Enter** on the login screen to sign in

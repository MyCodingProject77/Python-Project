"""
Reusable styled widgets for School Management System.
"""
import tkinter as tk
from tkinter import ttk
from theme import *


# ─────────────────────────────────────────────────────────────────────────────
#  Styled entry
# ─────────────────────────────────────────────────────────────────────────────

class StyledEntry(tk.Frame):
    """Label + Entry with bottom-border focus ring."""

    def __init__(self, parent, label="", show=None, width=28, **kw):
        super().__init__(parent, bg=BG_CARD, **kw)
        tk.Label(self, text=label, bg=BG_CARD, fg=TEXT_MUTED,
                 font=FONT_SMALL).pack(anchor="w")
        self._var = tk.StringVar()
        opts = dict(textvariable=self._var, font=FONT_ENTRY,
                    bg=BG_CARD2, fg=TEXT_PRIMARY, insertbackground=TEXT_PRIMARY,
                    relief="flat", bd=0, highlightthickness=1,
                    highlightbackground=BORDER, highlightcolor=ACCENT,
                    width=width)
        if show:
            opts["show"] = show
        self._entry = tk.Entry(self, **opts)
        self._entry.pack(fill="x", ipady=6, pady=(2, 0))

    def get(self):
        return self._var.get()

    def set(self, val):
        self._var.set(val)

    def clear(self):
        self._var.set("")

    def focus(self):
        self._entry.focus_set()


# ─────────────────────────────────────────────────────────────────────────────
#  Styled button
# ─────────────────────────────────────────────────────────────────────────────

class StyledButton(tk.Label):
    """Clickable label that looks like a pill button."""

    def __init__(self, parent, text="", command=None,
                 bg=ACCENT, fg="white", hover=ACCENT_HOVER,
                 width=None, **kw):
        opts = dict(text=text, bg=bg, fg=fg, font=FONT_BTN,
                    cursor="hand2", relief="flat", pady=8, padx=16)
        if width:
            opts["width"] = width
        super().__init__(parent, **opts, **kw)
        self._bg = bg
        self._hover = hover
        self._cmd = command
        self.bind("<Button-1>", self._on_click)
        self.bind("<Enter>",    lambda e: self.config(bg=hover))
        self.bind("<Leave>",    lambda e: self.config(bg=bg))

    def _on_click(self, _):
        if self._cmd:
            self._cmd()


# ─────────────────────────────────────────────────────────────────────────────
#  Styled Treeview (table)
# ─────────────────────────────────────────────────────────────────────────────

def make_treeview(parent, columns: list, height=14):
    """Return a configured ttk.Treeview with scrollbar."""
    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Custom.Treeview",
                    background=BG_CARD2, foreground=TEXT_PRIMARY,
                    fieldbackground=BG_CARD2, rowheight=30,
                    borderwidth=0, font=FONT_LABEL)
    style.configure("Custom.Treeview.Heading",
                    background=ACCENT, foreground="white",
                    font=FONT_LABEL_B, relief="flat")
    style.map("Custom.Treeview",
              background=[("selected", ACCENT)],
              foreground=[("selected", "white")])

    frame = tk.Frame(parent, bg=BG_DARK)
    scrolly = tk.Scrollbar(frame, orient="vertical")
    scrollx = tk.Scrollbar(frame, orient="horizontal")

    tree = ttk.Treeview(frame, columns=columns, show="headings",
                        style="Custom.Treeview", height=height,
                        yscrollcommand=scrolly.set,
                        xscrollcommand=scrollx.set)

    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=120, anchor="center")

    scrolly.config(command=tree.yview)
    scrollx.config(command=tree.xview)
    scrolly.pack(side="right", fill="y")
    scrollx.pack(side="bottom", fill="x")
    tree.pack(fill="both", expand=True)

    return frame, tree


# ─────────────────────────────────────────────────────────────────────────────
#  Stat card
# ─────────────────────────────────────────────────────────────────────────────

class StatCard(tk.Frame):
    def __init__(self, parent, title, icon, color, **kw):
        super().__init__(parent, bg=BG_CARD, bd=0, relief="flat",
                         padx=24, pady=20, **kw)
        # colour strip on left
        strip = tk.Frame(self, bg=color, width=5)
        strip.pack(side="left", fill="y")

        inner = tk.Frame(self, bg=BG_CARD)
        inner.pack(side="left", padx=(18, 0))

        tk.Label(inner, text=icon, font=(FONT_FAMILY, 26),
                 bg=BG_CARD, fg=color).pack(anchor="w")
        self._count_var = tk.StringVar(value="0")
        tk.Label(inner, textvariable=self._count_var,
                 font=FONT_LARGE_B, bg=BG_CARD, fg=TEXT_PRIMARY).pack(anchor="w")
        tk.Label(inner, text=title, font=FONT_LABEL,
                 bg=BG_CARD, fg=TEXT_MUTED).pack(anchor="w")

    def set_count(self, n):
        self._count_var.set(str(n))


# ─────────────────────────────────────────────────────────────────────────────
#  Separator
# ─────────────────────────────────────────────────────────────────────────────

def hsep(parent):
    tk.Frame(parent, bg=BORDER, height=1).pack(fill="x", pady=8)


# ─────────────────────────────────────────────────────────────────────────────
#  Combobox
# ─────────────────────────────────────────────────────────────────────────────

class StyledCombo(tk.Frame):
    def __init__(self, parent, label="", values=(), width=26, **kw):
        super().__init__(parent, bg=BG_CARD, **kw)
        tk.Label(self, text=label, bg=BG_CARD, fg=TEXT_MUTED,
                 font=FONT_SMALL).pack(anchor="w")
        style = ttk.Style()
        style.configure("Dark.TCombobox",
                         fieldbackground=BG_CARD2, background=BG_CARD2,
                         foreground=TEXT_PRIMARY, selectbackground=ACCENT)
        self._var = tk.StringVar()
        self._combo = ttk.Combobox(self, textvariable=self._var,
                                   values=list(values), width=width,
                                   state="readonly", style="Dark.TCombobox",
                                   font=FONT_ENTRY)
        self._combo.pack(fill="x", ipady=4, pady=(2, 0))

    def get(self):
        return self._var.get()

    def set(self, val):
        self._var.set(val)

    def set_values(self, vals):
        self._combo["values"] = list(vals)

    def clear(self):
        self._var.set("")
